'''
Created on 5 jun. 2020

@author: RSSpe
'''

def suma(a, b):
    """La suma de 2 + 2 es igual a 4
    >>> suma(2,2)
    4
    """
    return a + b


import doctest
doctest.testmod()